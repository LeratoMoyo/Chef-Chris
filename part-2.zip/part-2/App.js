import React, {useState} from 'react';
import {
  View,
  Text,
  Button,
  Alert,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  } from 'react-native';
  export default function App () {
  const menuItems = [
    { 
      category: 'Starter',
      items:'Bread sticks, Salmon sushi, Green salad @R80',
      image: require('./assets/assets/starter.png'),
    },
    {
      category: 'Main',
      items: 'Rice and chicken stew, Pap and mogodu, Pasta and tuna @R150',
      image: require('./assets/assets/main.png'),
    },
    {
      category: 'Dessert',
      items: 'Cake of the day, Ice cream with chocolate sauce and Fruit salad @R120',
      image: require('./assets/assets/dessert.png'),
    },
  ];

  return (
    <ScrollView contentContainerStyle={styles.homeContainer}>
    <Image source={require('./assets/assets/logo.png')} style={styles.logo} />
    <Text style={styles.menuTitle}>Menu</Text>

    {menuItems.map((menu, index) => (
    <View key={index} style={styles.menuItem}>
     <View style={{ flex:1}}>
      <Text style={styles.category}>{menu.category}</Text>
       <Text>{menu.items}</Text>
    </View>
    <Image source={menu.image} style={styles.menuImage} />
    </View> 
  ))}

  <TouchableOpacity onPress={() => Alert.alert ('More items coming!')}>
    <Text style={styles.moreLink}>Click for more</Text>
    </TouchableOpacity>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
homeContainer: {
  padding: 20,
  backgroundColor: '#fff',
},
logo: {
  width: 120,
  height: 120,
  alignSelf: 'center',
  marginBottom: 10,
  resizeMode: 'contain',
},
menuTitle: {
  fontSize: 26,
  fontWeight: 'bold',
  color: 'orange',
  textAlign: 'center',
  marginBottom:20,
},
menuItem: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 20,
  backgroundColor: '#f9f9f9',
  borderRadius:10,
  padding:10,
},
category: {
  fontWeight: 'bold',
  fontSize: 18,
  marginBottom: 4,
},
menuImage: {
  width: 80,
  height: 80,
  borderRadius: 10,
  marginLeft: 10,
},
moreLink: {
  color: 'orange',
  textAlign: 'center',
  marginVertical: 20,
  fontWeight: 'bold'
},
});

