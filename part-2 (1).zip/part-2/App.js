import React, {useState} from 'react';
import {
  View,
  Text,
  Button,
  Alert,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  TextInput,
  Modal,
  } from 'react-native';
  import {NavigationContainer} from '@react-navigation/native';
  import {createStackNavigator} from '@react-navigation/stack';

  const Stack = createStackNavigator ();

  function LoginScreen ({navigation}) {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');

    const handleLogin = () => {
      if (!name.trim() || !email.trim()) {
        Alert.alert('Error', 'Please enter both name and email');
        return;
      }
      const isChef =
      name.toLowerCase() === 'chef chris' &&
      email.toLowerCase() === 'chris@chefs.com';

      navigation.replace('Home', {user: name, isChef});
    };
    return (
      <View style={styles.container}>
       <Text style={styles.title}>Chef Login</Text>

       <Text>Name</Text>
       <TextInput
       placeholder="Enter your name"
       value={name}
       onChangeText={setName}
       style={styles.input}
       />

       <Text>Email</Text>
       <TextInput
       placeholder="Enter your email"
       value={email}
       onChangeText={setEmail}
       style={styles.input}
       keyboardType="email-address"
       autoCapitalize="none"
       />

       <Button title="Login" onPress={handleLogin} color="orange"/>

       <TouchableOpacity
       style={{marginTop:20}}
       onPress={() => navigation.replace('Home', {user: 'Guest', isChef: false})}
       >
       <Text style={{color: 'orange', textAlign: 'center'}}>
       Continue as Customer
       </Text>
       </TouchableOpacity>
       </View>
    );
  }

  function HomeScreen ({route, navigation}) {
    const {user, isChef} = route.params || { user: 'Guest', isChef: false};

    const [menuItems, setMenuItems] = useState([
      {
        id: 1,
      category: 'Starter',
      items:'Bread sticks, Salmon sushi, Green salad',
      price:  80,
      image: require('./assets/assets/starter.png'),
    },
    {
      id: 2,
      category: 'Main',
      items: 'Rice and chicken stew, Pap and mogodu, Pasta and tuna',
      price: 150,
      image: require('./assets/assets/main.png'),
    },
    {
      id: 3,
      category: 'Dessert',
      items: 'Cake of the day, Ice cream with chocolate sauce and Fruit salad',
      price: 120,
      image: require('./assets/assets/dessert.png'),
    },
  ]);

  const [editMode, setEditMode] = useState(false);

  const handleItemChange = (id, field, value) => {
    const updated = menuItems.map((item) =>
    item.id === id ? { ... item, [field]: value} : item
    );
    setMenuItems (updated);
  };

  return (
    <ScrollView contentContainerStyle={styles.homeContainer}>
    <Image source={require('./assets/assets/logo.png')} style={styles.logo} />
    <Text style={styles.menuTitle}>Menu</Text>

    {isChef && (
      <TouchableOpacity
      style={styles.editButton}
      onPress={() => setEditMode(!editMode)}
      >
      <Text style={styles .editButtonText}>
      {editMode ? 'Done Editing' : 'Edit Menu'}
      </Text>
      </TouchableOpacity>
    )}

{menuItems.map((menu) => (
  <View key={menu.id} style={styles.menuItem}>
  <View style={{ flex: 1}}>
  {editMode && isChef? (
    <>
    <TextInput
    style={styles.input}
    value={menu.category}
    onChangeText={(text) =>
    handleItemChange(menu.id, 'category', text)
    }
    />
    <TextInput
    style={styles.input}
    value={menu.items}
    onChangeText={(text) =>
    handleItemChange(menu.id, 'items', text)
    }
    />
    </>
  ):(
    <>
    <Text style={styles.category}>{menu.category}</Text>
    <Text>{menu.items}</Text>
    </>
  )}
  </View>
<Image source={menu.image} style={styles.menuImage} />
</View>
))}

{isChef && (
  <Button
  title={editMode ? 'Save Changes' : 'Edit Menu'}
  color="orange"
  onPress={() => setEditMode (editMode)}
  />
)}

  <TouchableOpacity onPress={() => Alert.alert('More items coming soon!')}>
  <Text style={styles.moreLink}>Click for more </Text>
  </TouchableOpacity>

  <Button title="Logout" color="orange" onPress={() => navigation.replace('Login')}
  />
  </ScrollView>
);
  }
 export default function App() {
   return (
     <NavigationContainer>
     <Stack.Navigator initialRouteName="Login">
     <Stack.Screen name="Login" component={LoginScreen}/>
     <Stack.Screen name="Home" component={HomeScreen}/>
     </Stack.Navigator>
    </NavigationContainer>
   );
 } 

const styles = StyleSheet.create({
homeContainer: {
  padding: 20,
  marginTop: 20,
  backgroundColor: '#fff',
  flex: 1,
},
input: {
  borderWidth: 1,
  borderRadius: 8,
  padding: 8,
  marginBottom: 15,
},
title: {
  fontSize: 22,
  fontWeight: 'bold',
  marginBottom: 15,
},
dropdown: {
  borderWidth: 1,
  borderRadius: 8,
  padding: 12,
  marginTop: 8,
},
modalOverlay: {
  flex: 1,
  backgroundColor: 'rgba(0,0,0,0.3)',
  justifyContent: 'center',
  padding: 20,
},
modalContent: {
  backgroundColor: '#fff',
  borderRadius: 8,
  maxHeight: '60%',
  paddingVertical: 8,
},

homeContainer: {
  padding: 20,
  backgroundColor: '#fff',
},
logo: {
  width: 120,
  height: 120,
  alignSelf: 'center',
  marginBottom: 10,
  resizeMode: 'contain',
},
menuTitle: {
  fontSize: 26,
  fontWeight: 'bold',
  color: 'orange',
  textAlign: 'center',
  marginBottom:20,
},
menuItem: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 20,
  backgroundColor: '#f9f9f9',
  borderRadius:10,
  padding:10,
},
category: {
  fontWeight: 'bold',
  fontSize: 18,
  marginBottom: 4,
},
menuImage: {
  width: 80,
  height: 80,
  borderRadius: 10,
  marginLeft: 10,
},
moreLink: {
  color: 'orange',
  textAlign: 'center',
  marginVertical: 20,
  fontWeight: 'bold',
},
});


























